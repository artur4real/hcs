import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget, QLabel, QPushButton, QTextEdit
import pymysql

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        # Устанавливаем заголовок окна и его размеры
        self.setWindowTitle("ЖКХ Ремонтные работы")
        self.setGeometry(100, 100, 600, 400)

        # Создаем главный виджет и устанавливаем его в центр окна
        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)

        # Создаем вертикальный макет для размещения элементов управления
        self.layout = QVBoxLayout(self.central_widget)

        # Создаем метку для отображения информации о ремонтных работах
        self.label = QLabel("Ремонтные работы бригады:")
        self.layout.addWidget(self.label)

        # Создаем текстовое поле для вывода информации
        self.text_area = QTextEdit()
        self.layout.addWidget(self.text_area)

        # Создаем кнопки для выполнения различных запросов к базе данных
        self.workers_button = QPushButton("Информация о работниках бригады")
        self.workers_button.clicked.connect(self.get_workers_info)
        self.layout.addWidget(self.workers_button)

        self.repairs_button = QPushButton("Информация о заказчиках и ремонте")
        self.repairs_button.clicked.connect(self.get_repairs_info)
        self.layout.addWidget(self.repairs_button)

        self.total_repairs_button = QPushButton("Общее количество ремонтных работ каждой бригады")
        self.total_repairs_button.clicked.connect(self.get_total_repairs)
        self.layout.addWidget(self.total_repairs_button)

        self.top_three_button = QPushButton("Топ-3 бригад")
        self.top_three_button.clicked.connect(self.get_top_three_workers)
        self.layout.addWidget(self.top_three_button)

    # Метод для выполнения SQL-запросов к базе данных
    def execute_query(self, query):
        try:
            # Устанавливаем соединение с базой данных
            connection = pymysql.connect(host="localhost", user="root", password="root", database="hcs")
            with connection.cursor() as cursor:
                cursor.execute(query)
                result = cursor.fetchall()
            return result
        except Exception as e:
            # В случае ошибки выводим сообщение об ошибке
            self.text_area.append("Ошибка при выполнении запроса к базе данных.")
            return None

    # Метод для получения информации о работниках бригады
    def get_workers_info(self):
        self.text_area.clear()
        query = "SELECT * FROM workers"
        result = self.execute_query(query)
        if result:
            self.text_area.append("Информация о работниках бригады:")
            for worker in result:
                self.text_area.append(f"ФИО: {worker[1]}, Квалификация: {worker[2]}, Специальность: {worker[3]}")

    # Метод для получения информации о заказчиках и ремонте
    def get_repairs_info(self):
        self.text_area.clear()
        query = "SELECT c.full_name, c.phone, r.repair_type, r.repair_date FROM customers c JOIN repairs r ON c.customer_id = r.customer_id"
        result = self.execute_query(query)
        if result:
            self.text_area.append("Информация о заказчиках и ремонте:")
            for info in result:
                self.text_area.append(f"Заказчик: {info[0]}, Телефон: {info[1]}, Вид ремонта: {info[2]}, Дата выполнения: {info[3]}")

    # Метод для получения общего количества ремонтных работ каждой бригады
    def get_total_repairs(self):
        self.text_area.clear()
        query = "SELECT w.brigade, r.repair_type, COUNT(r.repair_id) AS total_repairs FROM workers w LEFT JOIN repairs r ON w.worker_id = r.worker_id GROUP BY w.brigade, r.repair_type"
        result = self.execute_query(query)
        if result:
            self.text_area.append("Общее количество ремонтных работ каждой бригады по типам:")
            for row in result:
                self.text_area.append(f"{row[0]} ({row[1]}): {row[2] if row[2] else 0}")

    # Метод для получения списка топ-3 бригад
    def get_top_three_workers(self):
        self.text_area.clear()
        query = "SELECT w.brigade, COUNT(r.repair_id) AS total_repairs FROM workers w LEFT JOIN repairs r ON w.worker_id = r.worker_id GROUP BY w.brigade ORDER BY total_repairs DESC LIMIT 3"
        result = self.execute_query(query)
        if result:
            self.text_area.append("Топ-3 бригад:")
            for row in result:
                self.text_area.append(f"{row[0]}: {row[1]}")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
